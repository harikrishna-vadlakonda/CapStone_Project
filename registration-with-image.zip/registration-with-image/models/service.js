const mongoose = require('mongoose');
const Schema = mongoose.Schema;

const storySchema = new Schema ({
    name : {
        type : String,
        required : true
    },
    mobilenumber : {
      type = Number,
      required : true  
    },
    category: [{
        type : mongoose.Types.ObjectId, default : ["noname Sevice"], ref : "Category"}],
    city : {
        type : String,
        required : true
    },
    servicesusedby : {type: mongoose.Types.ObjectId, required: true, ref: 'User'},
})
module.exports = mongoose.model('Service', serviceSchema);