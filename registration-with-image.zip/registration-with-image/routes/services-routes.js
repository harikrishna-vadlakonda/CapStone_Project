const express = require('express');
const {chack} = require ('express-validator')

const servicesController = require('../controller/services-controllers')
const checkAuth = require('../middleware/check-auth');

const router = express.Router();

router.get('/', serivcesControllers.getAllservices);

router.get('/servicesbyid', serivcesControllers.getServicesById);
router.get('/user/uid', serivcesControllers.getServicesById);
router.use(checkAuth);

router.post(
    '/',
        check('name')
            .not()
            .isEmpty(),
        check('mobilenumber'),
        check('category'),
        check('city'),
    servicesController.createServices
);

router.patch(
    '/servicesbyid',
    check('name')
            .not()
            .isEmpty(),
        check('mobilenumber'),
        check('category'),
        check('city'),
    serivcesControllers.updateServices
);

router.delete('/servicesbyid', serivcesControllers.deleteServices);;


module.exports = router;