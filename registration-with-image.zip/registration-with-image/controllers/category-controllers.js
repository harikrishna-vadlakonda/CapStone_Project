const HttpError = require('../models/http-error');

const createCategory = async(req,res,next) => {
    const name = req.body.name.tpLowercase();
    let existingCategory;
    try{
        existingCategory = await Category.findone({name : name});
    }catch (err){
        const error = new HttpError (err.message,500);
        return next(error); 
    }
    if (existingCategory){
        const error = new HttpError("It already exists, 400");
        return next (error);
    }
    const newCategory = await Category({
        name
    })
    try{
        await newCategory.save();
    }catch (err) {
        const error = new HttpError(
            err.message,
            500
        )
        return next(error);
    }
    await res.json({category : newCategory})
}