const {validationResult} = require('express-validator');
const mongoose = require('mongoose');

const HttpError = require('../models/http-error');
const Services = require('../models/services');
const User = require('../models/user');


const getAllServices = async (req, res, next) => {
    let services;
    try {
        services = await services.find();
    } catch (err) {
        const error = new HttpError(
            'Fetching services failed, please try again later.',
            500
        );
        return next(error);
    }

    if (!services || services.length === 0) {
        return next(
            new HttpError('Could not find any services at the moment.', 404)
        );
    }
    await res.json({
        services: services.map(services =>
            services.toObject({getters: true})
        )
    });
};
const getservicesById = async (req, res, next) => {
    const servicesId = req.params.sid;

    let services;
    try {
        services = await services.findById(servicesId);
    } catch (err) {
        const error = new HttpError(
            'Something went wrong, could not find a services.',
            500
        );
        return next(error);
    }

    if (!services) {
        const error = new HttpError(
            'Could not find services for the provided id.',
            404
        );
        return next(error);
    }

    await res.json({services: services.toObject({getters: true})});
};

const getservicesByUserId = async (req, res, next) => {
    const userId = req.params.uid;

    // let services;
    let userWithservices;
    try {
        userWithservices = await User.findById(userId).populate('services');
    } catch (err) {
        const error = new HttpError(
            'Fetching services failed, please try again later.',
            500
        );
        return next(error);
    }

    // if (!services || services.length === 0) {
    if (!userWithservices) {
        return next(
            new HttpError('Could not find provided user id.', 404)
        );
    }

    await res.json({
        services: userWithservices.services.map(services =>
            services.toObject({getters: true})
        )
    });
};

const createservices = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return next(
            new HttpError('Invalid inputs passed, please check your data.', 422)
        );
    }
    const loggedInUserId = req.userData.userId;
    const {name,mobilenumber,city, isAnonymous} = req.body;
    const date = Date().toLocaleString();
    }
    const createdservices = new services({
        name,
        mobilenumber,
        city
    });


const updateservices = async (req, res, next) => {
    const errors = validationResult(req);
    if (!errors.isEmpty()) {
        return next(
            new HttpError('Invalid inputs passed, please check your data.', 422)
        );
    }

    const {name,mobilenumber,city, isAnonymous} = req.body;
    const servicesbyId = req.params.servicesbyid;

    let services;
    try {
        services = await services.findById(servicesbyId);
    } catch (err) {
        const error = new HttpError(
            'Something went wrong, could not update services.',
            500
        );
        return next(error);
    }

    services.name = name;
    services.mobilenumber = mobilenumber;
    services.city = city;

    try {
        await services.save();
    } catch (err) {
        const error = new HttpError(
            'Something went wrong, could not update services.',
            500
        );
        return next(error);
    }

    res.status(200).json({
        services: services.toObject(
            {getters: true})
    });
};

const deleteservices = async (req, res, next) => {
    const servicesbyId = req.params.servicesbyid;
    const loggedInUserId = req.userData.userId;
    let services;
    try {
        services = await services.findById(servicesbyId).poulate('serviceusedby ');
    } catch (err) {
        const error = new HttpError(
            err.message,
            500
        );
        return next(error);
    }

    if (!services) {
        const error = new HttpError('Could not find services for this id.', 404);
        return next(error);
    }
    if (services.serviceusedby .id === loggedInUserId) {
        try {
            const sess = await mongoose.startSession();
            sess.startTransaction();
            await services.remove();
            services.serviceusedby .services.pull(services);
            await services.serviceusedby .save();
            await sess.commitTransaction();
        } catch (err) {
            const error = new HttpError(
                err.message,
                500
            );
            return next(error);
        }

        res.status(200).json({message: 'Deleted services.'});
    } else {
        await res.json({message: "Not your services to delete"});
    }

};

const searchservices = async (req, res, next) => {
    const query = req.params.query;
    let results;
    try {
        let agg = services.aggregate([{
            $search: {
                "text": {
                    "query": query, "path": ["city", "category", "mobilenumber"], "fuzzy": {
                        "maxEdits": 2,
                        "maxExpansions": 20,
                    }
                }
            }
        }, {
            $project: {
                "city": 1,
            }
        }]);
        results = await agg.exec();
    } catch (err) {
        const error = new HttpError(err.message, 404);
        return next(error);
    }
    if (results.length === 0) {
        await res.json({results: "No results found!!"});
    } else {
        await res.json({results: results});
    }

};


exports.getservicesById = getservicesById;
exports.getservicesByUserId = getservicesByUserId;
exports.createservices = createservices;
exports.updateservices = updateservices;
exports.deleteservices = deleteservices;
exports.getAllservices = getAllservices;
exports.searchservices = searchservices;


